// SchoolProgram.cs
// Chương trình quản lý trường học bằng C# (refactor từ BAD CODE)
// Quản lý: Sinh viên, Giáo viên, Môn học, Đăng ký, Điểm
// Tạm thời minh họa phần Sinh viên (các phần khác làm tương tự)

using System;
using System.Collections.Generic;
using System.Linq;

class Student
{
    public string Id { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }
    public double GPA { get; set; }

    public override string ToString()
    {
        return $"ID:{Id} Name:{Name} Age:{Age} GPA:{GPA}";
    }
}

public class SchoolProgram
{
    static List<Student> students = new List<Student>();
    // List<Teacher> teachers = new List<Teacher>();  // Tương tự
    // List<Course> courses = new List<Course>();    // Tương tự
    // List<Enrollment> enrollments = new List<Enrollment>(); 
    // List<Grade> grades = new List<Grade>();       

    public static void Main(string[] args)
    {
        int menu = 0;
        while (menu != 99)
        {
            Console.WriteLine("============= MENU CHINH =============");
            Console.WriteLine("1. Quan ly Sinh vien");
            Console.WriteLine("2. Quan ly Giao vien");
            Console.WriteLine("3. Quan ly Mon hoc");
            Console.WriteLine("4. Quan ly Dang ky hoc");
            Console.WriteLine("5. Quan ly Diem");
            Console.WriteLine("6. Bao cao tong hop");
            Console.WriteLine("99. Thoat");
            Console.Write("Nhap lua chon: ");

            if (!int.TryParse(Console.ReadLine(), out menu))
                menu = 0;

            switch (menu)
            {
                case 1: StudentMenu(); break;
                case 99: Console.WriteLine("Thoat chuong trinh."); break;
                default: Console.WriteLine("Lua chon khong hop le!"); break;
            }
        }
    }

    // ================== MENU SINH VIÊN ==================
    static void StudentMenu()
    {
        int smenu = 0;
        while (smenu != 9)
        {
            Console.WriteLine("\n--- QUAN LY SINH VIEN ---");
            Console.WriteLine("1. Them SV");
            Console.WriteLine("2. Xoa SV");
            Console.WriteLine("3. Cap nhat SV");
            Console.WriteLine("4. Hien thi tat ca SV");
            Console.WriteLine("5. Tim SV theo ten");
            Console.WriteLine("6. Tim SV GPA > 8");
            Console.WriteLine("7. Sap xep theo ten");
            Console.WriteLine("8. Sap xep theo GPA");
            Console.WriteLine("9. Quay lai");
            Console.Write("Nhap lua chon: ");

            if (!int.TryParse(Console.ReadLine(), out smenu))
                smenu = 0;

            switch (smenu)
            {
                case 1: AddStudent(); break;
                case 2: RemoveStudent(); break;
                case 3: UpdateStudent(); break;
                case 4: ShowAllStudents(); break;
                case 5: SearchByName(); break;
                case 6: ShowExcellentStudents(); break;
                case 7: SortByName(); break;
                case 8: SortByGPA(); break;
                case 9: Console.WriteLine("Quay lai MENU CHINH"); break;
                default: Console.WriteLine("Lua chon khong hop le!"); break;
            }
        }
    }

    // ============= CÁC CHỨC NĂNG SINH VIÊN =============
    static void AddStudent()
    {
        Console.Write("Nhap ID: ");
        string id = Console.ReadLine();
        Console.Write("Nhap ten: ");
        string name = Console.ReadLine();
        Console.Write("Nhap tuoi: ");
        int age = int.Parse(Console.ReadLine());
        Console.Write("Nhap GPA: ");
        double gpa = double.Parse(Console.ReadLine());

        students.Add(new Student { Id = id, Name = name, Age = age, GPA = gpa });
        Console.WriteLine("Da them sinh vien!");
    }

    static void RemoveStudent()
    {
        Console.Write("Nhap ID can xoa: ");
        string id = Console.ReadLine();
        var st = students.FirstOrDefault(s => s.Id == id);
        if (st != null)
        {
            students.Remove(st);
            Console.WriteLine("Da xoa sinh vien!");
        }
        else Console.WriteLine("Khong tim thay sinh vien!");
    }

    static void UpdateStudent()
    {
        Console.Write("Nhap ID can cap nhat: ");
        string id = Console.ReadLine();
        var st = students.FirstOrDefault(s => s.Id == id);
        if (st != null)
        {
            Console.Write("Nhap ten moi: ");
            st.Name = Console.ReadLine();
            Console.Write("Nhap tuoi moi: ");
            st.Age = int.Parse(Console.ReadLine());
            Console.Write("Nhap GPA moi: ");
            st.GPA = double.Parse(Console.ReadLine());
            Console.WriteLine("Cap nhat thanh cong!");
        }
        else Console.WriteLine("Khong tim thay sinh vien!");
    }

    static void ShowAllStudents()
    {
        if (students.Count == 0) Console.WriteLine("Danh sach trong.");
        else students.ForEach(s => Console.WriteLine(s));
    }

    static void SearchByName()
    {
        Console.Write("Nhap ten: ");
        string name = Console.ReadLine();
        var result = students.Where(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        foreach (var s in result) Console.WriteLine("Tim thay: " + s);
    }

    static void ShowExcellentStudents()
    {
        var result = students.Where(s => s.GPA > 8.0);
        foreach (var s in result) Console.WriteLine("Sinh vien gioi: " + s);
    }

    static void SortByName()
    {
        students = students.OrderBy(s => s.Name).ToList();
        Console.WriteLine("Da sap xep theo ten!");
    }

    static void SortByGPA()
    {
        students = students.OrderByDescending(s => s.GPA).ToList();
        Console.WriteLine("Da sap xep theo GPA!");
    }
}
